# VibeOS SVG Logo Pack

Includes matching SVG app icons made for your VibeOS desktop grid.

## App icons
- notes.svg
- music.svg
- surf.svg
- gallery.svg
- files.svg
- settings.svg
- vibestore.svg
- calculator.svg
- focus.svg

## Extra system assets
- folder.svg
- txt-file.svg

Each SVG is 512x512 with a transparent canvas, so you can use it directly in your UI. PNG exports are also included at 512px and 256px.
